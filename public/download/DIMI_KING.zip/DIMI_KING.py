import pygame
import random
import time
from os import path
vec = pygame.math.Vector2

a = input()

pygame.font.init()

#SETTING
TITLE = "DIMI_KING"
WIDTH = 600
HEIGHT = 800
FPS = 60
PushButton = False
finish = False
HS_FILE = 'HS_FILE'

FONT_NAME = 'arial'

PLAYER_ACC  = 1.5
PLAYER_FRICTION = -0.08
PLAYER_GRAVITY = 0.8

PLATFORM_LIST  = [
    (0, HEIGHT - 40, WIDTH, 40),
    (WIDTH/2 - 50, HEIGHT*3/4, 100, 20),
    (125, HEIGHT - 350,100, 20 ),
    (350, 200, 100, 20),
    (172, 100, 50, 20)
]

WHITE = (255, 255, 255)
BLACK = (0,0,0)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)

Level = 20

class Player(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.image = pygame.Surface((30,40))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH/2, HEIGHT/2)

        self.pos = vec(WIDTH/2, HEIGHT/2) 
        self.vel = vec(0,0)
        self.acc = vec(0,0) 

    def jump(self):
        hits = pygame.sprite.spritecollide(self,self.game.platforms, False)
        self.rect.y -= 0.1
        if hits:
            self.vel.y = -21
    
    def update(self):
        self.acc = vec(0, PLAYER_GRAVITY)
        keys = pygame.key.get_pressed()

        if(keys[pygame.K_LEFT] or keys[pygame.K_a]):
            self.acc.x = -PLAYER_ACC
        if(keys[pygame.K_RIGHT] or keys[pygame.K_d]):
            self.acc.x = PLAYER_ACC

        self.acc.x += self.vel.x*PLAYER_FRICTION
        self.vel += self.acc
        self.pos += self.vel  +  0.7 * self.acc

        if(self.pos.x > WIDTH):
            self.pos.x = WIDTH
        if self.pos.x < 0:
            self.pos.x = 0
        self.rect.midbottom = self.pos

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, w, h):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((w, h))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Game:
    def __init__(self):
        WIDTH = 600
        HEIGHT = 800
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.running = False
        self.font_name = pygame.font.match_font(FONT_NAME)
        self.Level = 20
        self.load_data()

    def new(self):
        self.score = 0

        self.all_sprites = pygame.sprite.Group()
        self.platforms = pygame.sprite.Group()

        self.player = Player(self)
        self.all_sprites.add(self.player)

        for plat in PLATFORM_LIST:
            p = Platform(*plat)
            self.all_sprites.add(p)
            self.platforms.add(p)

        self.run()

    def run(self):
        self.playing = True
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()
        
    def update(self):
        self.all_sprites.update()

        if (self.player.vel.y > 0):
            hits = pygame.sprite.spritecollide(self.player, self.platforms, False)
            if (hits):
                lowest = hits[0]
                for hit in hits:
                    if(hit.rect.bottom > lowest.rect.bottom):
                        lowest = hit
                self.player.pos.y = lowest.rect.top +0.1
                self.player.vel.y = 0

        if (self.player.rect.top <= HEIGHT/13) :
            self.player.pos.y += max(abs(self.player.vel.y),5)
            for plat in self.platforms:
                plat.rect.y += max(abs(self.player.vel.y), 5)
                if(plat.rect.top >= HEIGHT):
                    plat.kill()
                    self.score += 10
                    if(self.score <= 75):
                        self.Level = 30
                    elif(self.score <=150):
                        self.Level = 10
                    elif(self.score <= 225):
                        self.Level = 5
                    elif(self.score <= 300):
                        PLAYER_FRICTION = -0.06
                        self.Level = 0
                    elif(self.score <= 375):
                        self.Level = -10
                        PLAYER_FRICTION = -0.05
                    elif(self.score <= 450):
                        PLAYER_FRICTION = -0.045
                    elif(self.score <= 525):
                        PLAYER_FRICTION = -0.04
                        self.Level = -20
                    elif(self.score <= 600):
                        PLAYER_FRICTION = -0.03
                        self.Level = -30
                    elif(self.score <= 700):
                        PLAYER_FRICTION = -0.005
                        self.Level = -37
        if (self.player.rect.bottom > HEIGHT):
            for sprite in self.all_sprites:
                sprite.rect.y -= max(self.player.vel.y,10)
                if(sprite.rect.bottom < 0):
                    sprite.kill()
        
        if(len(self.platforms) == 0):
            self.playing = False


        while len(self.platforms) < 6:
            width = random.randrange(60,100)
            p = Platform(random.randrange(0,WIDTH - width - self.Level),
                         random.randrange(-70, -40),
                         width+self.Level, 20 + (self.Level/5))
            self.platforms.add(p)
            self.all_sprites.add(p)

    def events(self):

        for event in pygame.event.get():

            if(event.type == pygame.QUIT):
                if(self.playing):
                    self.playing = False
                self.running = False
            if (event.type == pygame.KEYDOWN):
                if(event.key == pygame.K_SPACE):
                    self.player.jump()
    def draw(self):
        self.screen.fill(BLACK)
        self.all_sprites.draw(self.screen)
        self.draw_text(str(self.score), 22, WHITE, WIDTH/2, 15)
        pygame.display.flip()

    def show_start_screen(self):
        pass

    def show_go_screen(self):
        if not self.running:
            return
        self.screen.fill(BLACK)
        self.draw_text("GAME OVER", 48, WHITE, WIDTH/2, HEIGHT/4)
        self.draw_text("Score : " + str(self.score),
                       35, WHITE, WIDTH/2, HEIGHT/2 - 100)
        
        with open(path.join(self.dir, HS_FILE), 'a') as f:
            f.write(f'\n{a} {str(self.score)}')

        if(self.score > self.highscore):
            self.draw_text("New High Score : " + str(self.score),
               22, WHITE, WIDTH/2, HEIGHT/2)
            self.recoder = a
        elif(self.score < self.lowscore):
            self.draw_text("New Low Score!! : " + str(self.score),
               22, RED, WIDTH/2, HEIGHT/2)
            self.recoder = a
        else:
            self.draw_text("High Score : " + str(self.highscore),
               22, WHITE, WIDTH/2, HEIGHT/2)
        self.draw_text("recoded by " + self.recoder,
                     20, WHITE, WIDTH/2, HEIGHT/2+30)
        self.draw_text("Press a key to play again",
                       22, WHITE, WIDTH/2, HEIGHT*3/4)
        pygame.display.flip()
        self.wait_for_key()

    def draw_text(self, text, size, color, x, y):
        font_draw = pygame.font.Font(self.font_name, size)
        text_surface = font_draw.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x,y)
        self.screen.blit(text_surface, text_rect)

    def wait_for_key(self):
        self.load_data()
        waiting = True
        while waiting:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pygame.KEYUP:
                    waiting = False    
    def load_data(self):
        self.dir = path.dirname(__file__)
        try:
            with open(path.join(self.dir, HS_FILE), 'r') as f:
                all_recodes = f.read().split()
                self.recoder = ''
                self.highscore = 0
                self.lowscore = 100000000000000000
                for i in range(1, len(all_recodes), 2):
                    if(int(all_recodes[i]) > self.highscore):
                        self.highscore = int(all_recodes[i])
                        self.recoder = all_recodes[i-1]
                    if(int(all_recodes[i]) < self.lowscore):
                        self.lowscore = int(all_recodes[i])
        except FileNotFoundError:
            self.highscore = 0

MainScreen = pygame.display.set_mode([800, 800])

title_font = pygame.font.SysFont(None, 70, False, True)
title_text = title_font.render("DIMI KING", True, (255,0,255))
title_font_shadow = pygame.font.SysFont(None, 70, False, True)#rgb(237,18,128)
title_text_shadow = title_font_shadow.render("DIMI KING", True, (255,255,0))

start_font = pygame.font.SysFont(None, 45, True, True)
start_font_hover = pygame.font.SysFont(None, 57, True, True)
start_text = start_font.render("game start", True, (255,214,0))
start_text_hover = start_font_hover.render("game start", True, (255,214,0))

tutorial_font = pygame.font.SysFont(None, 45, True, True)
tutorial_font_hover = pygame.font.SysFont(None, 57, True, True)
tutorial_text = tutorial_font.render("tutorial", True, (255,214,0))
tutorial_text_hover = tutorial_font_hover.render("tutorial", True, (255,214,0))

ButtonList = []
Block_list = []

bottom = None

consoleX = 0
consoleY = 0

BACKGROUND = [153, 255, 255]
start_rect = (100, 300, 400, 100)
tutorial_rect = (100, 450, 400, 100)

class button:
    def __init__(self, rect, text, text_hover ,color,textPos, ClickAct=None):
        pygame.draw.rect(MainScreen, color, rect)
        MainScreen.blit(text,textPos)
        self.rect = rect
        self.color = color
        self.animateRect = (rect[0] -9, rect[1] - 9, rect[2] + 18, rect[3] + 18)

        self.ClickAction = ClickAct
        
        self.isHoverBool = False
        
        self.text = text
        self.text_hover = text_hover
        self.textPos = textPos
    
    def isHover(self, mousePos):
        if(self.rect[0] < mousePos[0] < (self.rect[0] + self.rect[2]) and self.rect[1] < mousePos[1] < (self.rect[1] + self.rect[3])):
            return True
        return False
    
    def ClickAction(self):
        self.ClickAction()
    
    def HoverAction(self):
        pygame.draw.rect(MainScreen, BACKGROUND, self.rect)
        self.isHoverBool = True
        for i in range(1,10):
            tempRect = (self.rect[0] - i, self.rect[1] - i, self.rect[2] + (i*2), self.rect[3] + (i*2))
            pygame.draw.rect(MainScreen, self.color, tempRect)
            MainScreen.blit(self.text_hover,(self.textPos[0] - 20, self.textPos[1] - 5))
            pygame.display.update()
            time.sleep(0.005)
    def reset(self):
        pygame.draw.rect(MainScreen, BACKGROUND, self.animateRect)
        pygame.draw.rect(MainScreen, self.color, self.rect)
        MainScreen.blit(self.text,self.textPos)
        pygame.display.update()

#게임 시작
def start_game():
    g.running = True
    ButtonList.clear()
    pass
def show_main_screen():
    global MainScreen
    MainScreen.fill(BACKGROUND)
    for i in range(10):
        MainScreen.blit(title_text_shadow, (175 + i,100 + i))
    MainScreen.blit(title_text,(175,100))

    start_button = button(start_rect, start_text, start_text_hover, [0,0,205], (220,335), start_game)
    ButtonList.append(start_button)
    tutorial_button = button(tutorial_rect, tutorial_text, tutorial_text_hover, [20,24,39], (250,485), )
    ButtonList.append(tutorial_button)
    pygame.display.update()


clock = pygame.time.Clock()
g = Game()
show_main_screen()
while  not finish:
    if(not pygame.mouse.get_pressed()[0] and PushButton):
        PushButton = False

    while g.running:
        g.new()
        g.show_go_screen()

    for Bt in ButtonList:
        if(Bt.isHover(pygame.mouse.get_pos())):
            if(not Bt.isHoverBool):
                Bt.HoverAction()
            if(pygame.mouse.get_pressed()[0] and not PushButton):
                PushButton = True
                Bt.ClickAction()
                GameStart = True
        elif(Bt.isHoverBool):
            Bt.reset()
            Bt.isHoverBool = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            finish = True
    

pygame.quit()